package dev.venin.cakefactory.web;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Cake {
    private String name;
}
