package dev.venin.cakefactory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakeFactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
